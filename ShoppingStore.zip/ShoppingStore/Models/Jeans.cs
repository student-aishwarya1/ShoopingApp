﻿using System.ComponentModel.DataAnnotations;

namespace ShoppingStore.Models
{
    public class Jeans
    {
        
            [Key]
            public int Id { get; set; }
            public string Brand { get; set; }
            public string Size { get; set; }
            public string Color { get; set; }
            public string Price { get; set; }
            public byte[] image { get; set; }

    }
}
