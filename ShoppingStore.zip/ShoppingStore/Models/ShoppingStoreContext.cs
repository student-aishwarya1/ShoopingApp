﻿using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace ShoppingStore.Models
{
    public class ShoppingStoreContext : DbContext
    {
       
            public ShoppingStoreContext(DbContextOptions<ShoppingStoreContext> options) : base(options) { }
            public DbSet<Cart> Shoppings { get; set; }
            public DbSet<Jeans> Jeanss { get; set; }
            public DbSet<Login> Logins { get; set; }
            public DbSet<Register> Registers { get; set; }
            public DbSet<Tshirt> Tshirts { get; set; }
           public DbSet<Cart> Carts { get; set; }



    }
}
