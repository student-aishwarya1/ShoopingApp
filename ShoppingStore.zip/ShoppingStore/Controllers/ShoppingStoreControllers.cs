﻿using Microsoft.AspNetCore.Mvc;

namespace ShoppingStore.Controllers
{
    public class ShoppingStoreControllers : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
